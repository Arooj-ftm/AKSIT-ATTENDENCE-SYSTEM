import { useState } from "react";
import { motion } from "framer-motion";
import { LayoutDashboard, Users, BarChart3, CalendarDays, Settings, LifeBuoy } from "lucide-react";
import Avatar from "./Avatar";
import "./Sidebar.css";

const items = [
  { icon: LayoutDashboard, label: "Overview" },
  { icon: Users, label: "Employees" },
  { icon: BarChart3, label: "Analytics" },
  { icon: CalendarDays, label: "Calendar" },
  { icon: Settings, label: "Settings" },
];

export default function Sidebar({ onNavigate }) {
  const [active, setActive] = useState("Overview");
  const [logoOk, setLogoOk] = useState(true);

  const go = (label) => {
    setActive(label);
    onNavigate?.(label);
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        {logoOk ? (
          <img src="/logo.png" alt="Aksit Global" onError={() => setLogoOk(false)} />
        ) : (
          <span className="sidebar-fallback">Aksit Global</span>
        )}
      </div>

      <p className="sidebar-label">Menu</p>
      <nav className="sidebar-nav">
        {items.map(({ icon: Icon, label }) => (
          <button
            key={label}
            onClick={() => go(label)}
            className={`sidebar-link ${active === label ? "active" : ""}`}
          >
            {active === label && <motion.div layoutId="active" className="sidebar-pill" />}
            {active === label && <motion.span layoutId="bar" className="sidebar-bar" />}
            <Icon size={18} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <button className="sidebar-link">
          <LifeBuoy size={18} />
          <span>Help center</span>
        </button>
        <div className="sidebar-admin">
          <Avatar name="Admin User" size="sm" id={0} />
          <div className="sidebar-admin-text">
            <p className="sidebar-admin-name truncate">Admin User</p>
            <p className="sidebar-admin-mail truncate">admin@aksitglobal.com</p>
          </div>
        </div>
      </div>
    </aside>
  );
}